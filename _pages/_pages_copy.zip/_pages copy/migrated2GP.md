---
title: Migrated2GP
layout: page
---

Welcome to new site!

Migrated2GP - Migrated to Github Page

Due to some technical (Wordpress markdown rendering) issuess, we had to migrate [inlovewithcode.wordpress.com](http://inlovewithcode.wordpress.com) to [inlovewithcode.github.io](http://inlovewithcode.github.io).

Although we have lost a lot valueble content due to issue with Wordpress, we hope this is good for us - as we get to write fresh content and reviews or notes.

Thank you.